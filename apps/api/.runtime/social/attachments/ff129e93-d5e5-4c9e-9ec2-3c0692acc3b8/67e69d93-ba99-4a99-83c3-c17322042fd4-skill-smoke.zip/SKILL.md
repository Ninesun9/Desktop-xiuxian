skill smoke
